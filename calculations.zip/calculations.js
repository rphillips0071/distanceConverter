

//having the defaultfunction on the webpage
////////////////////////////////////////////////////////////////////////
document.getElementById('convert').addEventListener('submit', function(event){
    event.preventDefault();

    let distance = document.getElementById('distance').value;
    let kilometersCalculation = (distance * 1.60934).toFixed(3);

    document.getElementById('answer').innerHTML = (`${distance} miles are equal to ${kilometersCalculation} kilometers`);

    if (isNaN(parseFloat(distance))) {
        alert('You need to type a numeric value.');
    }
});


document.addEventListener('keydown', function(event){
let key = event.code;
let heading = document.getElementById('firstHeading');
let headingP = document.getElementById('firstHeadingP');
let distance = document.getElementById('distance').value;
let kilometersCalculation = (distance * 1.60934).toFixed(3);
let milesCalculation = (distance * 0.621371).toFixed(3);
let containerTopP = document.getElementById('containerTopP');
//allowing the user to switch to calculate kilometers to miles
////////////////////////////////////////////////////////////////////////
    if (key === 'KeyK'){
        heading.innerHTML = ('KILOMETERS  TO MILES CONVERTER');
        headingP.innerHTML=('Press the "M" key to switch to convert kilometers to miles')
        containerTopP.innerHTML = ('Type in a number of kilometers and click the button to convert the distance to miles.')

        document.getElementById('convert').addEventListener('submit', function(event){
            event.preventDefault();
        
            let distance = document.getElementById('distance').value;

        
            document.getElementById('answer').innerHTML = (`${distance} kilometers are equal to ${milesCalculation} miles`);
        
        });
    }
    //allowing the user to switch to calculate miles to kilometers
////////////////////////////////////////////////////////////////////////
    else if (key === 'KeyM'){
        heading.innerHTML = ('MILES TO KILOMETERS CONVERTER');
        headingP.innerHTML=('Press the "K" key to switch to convert miles into kilometers');
        containerTopP.innerHTML = ('Type in a number of miles and click the button to convert the distance to kilometers.')

        document.getElementById('convert').addEventListener('submit', function(event){
            event.preventDefault();
        
        
            document.getElementById('answer').innerHTML = (`${distance} miles are equal to ${kilometersCalculation} kilometers`);
        
        });
    }


});

// calculate miles to kilometers and back with keystroke
    //change heading when switching